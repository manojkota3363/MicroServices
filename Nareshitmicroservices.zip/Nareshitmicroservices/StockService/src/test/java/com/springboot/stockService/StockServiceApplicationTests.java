package com.springboot.stockService;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
@SpringBootTest
public class StockServiceApplicationTests {


	public void contextLoads() {
	}

}
