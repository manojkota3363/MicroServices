package com.springboot.stock;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


@SpringBootTest
public class MicroServiceArchitectureApplicationTests {


	public void contextLoads() {
	}

}
