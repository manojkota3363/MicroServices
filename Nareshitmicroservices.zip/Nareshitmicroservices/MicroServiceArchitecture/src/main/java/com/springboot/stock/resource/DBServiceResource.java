package com.springboot.stock.resource;

import com.springboot.stock.model.Quote;
import com.springboot.stock.model.Quotes;
import com.springboot.stock.repository.QuotesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/rest/db/")
public class DBServiceResource {

    @Autowired
    private QuotesRepository quotesRepository;
    @GetMapping("{username}")
    public List<String> getAllQuotes(@PathVariable("username") String username){
        return getAllquotes(username);
    }

    private List<String> getAllquotes(String username) {
        List<Quote> quoteList=quotesRepository.findByUserName(username);
        return quoteList.stream().map(quote -> quote.getQuote()).collect(Collectors.toList());
    }
    @PostMapping("/add")
    public List<String> addQuotes(@RequestBody Quotes quotes){
        quotes.getQuotes().stream().map(quote->new Quote(quotes.getUserName(),quote)).forEach(quote->
                quotesRepository.save(quote));

        return getAllquotes(quotes.getUserName());
    }
    @PostMapping("/delete/{username}")
    public List<String> deleteAllQuotes(@PathVariable("username") String username){
        List<Quote> quoteList=quotesRepository.findByUserName(username);
        //It accepts all the list of records and delete them.
        quotesRepository.deleteAll(quoteList);
        return getAllquotes(username);
    }
}
