package com.springboot.EurekaService;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@SpringBootTest
public class EurekaServiceApplicationTests {


	public void contextLoads() {
	}

}
